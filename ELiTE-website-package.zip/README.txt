ELiTE WEBSITE PACKAGE

Files:
- index.html: existing ELiTE wellbeing app (login/OTP intentionally not included)
- manifest.webmanifest + elite-icon.svg: installable web-app metadata/icon
- service-worker.js: basic offline cache for same-origin files

Preview: open index.html in a browser. For install/offline features and correct service-worker behavior, host this folder on an HTTPS static host (for example Netlify, Cloudflare Pages, or GitHub Pages). Upload the CONTENTS of this folder, not the ZIP itself, using your host's deployment instructions.

This package does not create a public website URL by itself; hosting must be completed in an account you control. The existing app's features are preserved from the selected HTML base. No login/OTP is included, as requested.
